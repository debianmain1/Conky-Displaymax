#!/bin/bash

killall conky

conky -c ~/.conky/conkyrc_displaymax_6cpu ;

exit 0
